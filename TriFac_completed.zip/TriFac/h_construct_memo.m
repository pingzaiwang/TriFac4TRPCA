function memo=h_construct_memo(opts)
max_iter=opts.MAX_ITER_OUT;
memo.max_iter=max_iter;
memo.iter=0;
memo.fval=zeros(max_iter,1);
% relative error between every two iterations
memo.eps=zeros(max_iter,1);
% error: distance to the truth 
memo.err=zeros(max_iter,1);
memo.opts=opts;
