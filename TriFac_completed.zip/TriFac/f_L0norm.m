function L0 = f_L0norm(X)
L0=sum(abs(X(:))> 1e-12);
end