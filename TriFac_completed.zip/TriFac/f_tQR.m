function [tQ, tR]=f_tQR(X)
n1=size(X,1); n2=size(X,2);n3=size(X,3);
tQ = zeros(n1,n2,n3);
tR = rand(n2,n2,n3);
X = fft(X,[],3);
for k=1:n3
    [q,r]=qr(squeeze(X(:,:,k)),0);
    tQ(:,:,k)=q;
    tR(:,:,k)=r;
end
tQ = ifft(tQ,[],3);
tR = ifft(tR,[],3);
