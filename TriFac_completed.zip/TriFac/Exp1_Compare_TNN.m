clear
%% ++++++Settings+++++++
sz=[100 100 30];
sz=[200 200 30];
%sz=[160 160 30];
rankRatio=0.15;
sparseRatio=0.10;
rTubal = round(min(sz(1),sz(2))*rankRatio);
nSample=1;
alphaL=1;
alphaS=1;

%% ++++Initial Rank++++
rankUV=max(round(2*rTubal),15);

%% ++++Corruption Distribution++++
% ['Bernoulli', 'Gaussian']
% 0:bernulli, 1:Gaussian
OutlierDistribution=1;

%% Algorihm Swithches
methodList={'TNN','UV-TNN'};
nMethods = length(methodList);
isMethodOn=[0 1];
verbose=0;
%% +++ Signal Generation++++
d1=sz(1);d2=sz(2);d3=sz(3);
L = f_generate_low_tubal_rank_tensor(sz,rTubal);
L = L/h_tnorm(L)*sqrt(prod(sz));


Bs = zeros(sz);
vIdx=randperm(prod(sz));
vIdx = vIdx(1:round(prod(sz)*sparseRatio));

Bs(vIdx)=1;

% Sparse Tensor
if OutlierDistribution==0
    Ttmp1=rand(sz)<0.5;
    Ttmp2=ones(sz);
    S=(Ttmp2-2*Ttmp1)*alphaS;
else 
    S=randn(sz)*alphaS;
end
S=double(S.*Bs);

Y = L+S;

obs.tsize=sz;
obs.tY = Y;

mPSNR=zeros(nSample,nMethods);
mTime=zeros(nSample,nMethods);
startTime=clock;

iSample=1;
%% +++++TNN+++++
iMethod=1;
if isMethodOn(iMethod)
    rho=1e-4 ;
    nu=1.1;
    optTNN.MAX_ITER_OUT=200;
    optTNN.MAX_RHO=1e5;
    optTNN.MAX_EPS=1e-7;
    optTNN.verbose=verbose;
    optTNN.para.rho=rho;
    optTNN.para.nu=nu;
    optTNN.para.lambdaS=1/sqrt(max(sz(1),sz(2))*sz(3));
    % -------------Options-------------
    
    %-------------Memo----------------
    memoTNN=h_construct_memo(optTNN);
    memoTNN.truthL=double(L);
    memoTNN.truthS=double(S);
    %-------------Memo----------------
    
    %------------------------------------
    tic
    memoTNN=f_trpca_tnn(obs,optTNN,memoTNN);
    t=toc;
    memo = memoTNN;
    
    iter = memo.iter;
    mPSNR(iSample,iMethod)=memo.psnr(iter);
    mTime(iSample,iMethod)=t;
end

%% +++++TNN_UV+++++
iMethod=2;
if isMethodOn(iMethod)
    % -------------Options-------------
    rho=1e-2;
    nu=1.1;
    
    optTNN_UV.MAX_ITER_OUT=100;
    optTNN_UV.MAX_RHO=1e5;
    optTNN_UV.MAX_EPS=1e-7;
    optTNN_UV.verbose=verbose;
    optTNN_UV.para.rho=rho;
    optTNN_UV.para.nu=nu;
    optTNN_UV.para.r=rankUV;
    optTNN_UV.para.lambdaS=1/sqrt(max(sz(1),sz(2))*sz(3));
    % -------------Options-------------
    
    %-------------Memo----------------
    memoTNN_UV=h_construct_memo(optTNN_UV);
    memoTNN_UV.truthL=L;
    memoTNN_UV.truthS=S;
    %-------------Memo----------------
    obsCTNN.tY = obs.tY;
    %------------------------------------
    tic
    memoTNN_UV=f_trpca_tnn_trifac(obsCTNN,optTNN_UV,memoTNN_UV);
    t=toc;
    memo = memoTNN_UV;
    
    iter = memo.iter;
    mPSNR(iSample,iMethod)=memo.psnr(iter)
    mTime(iSample,iMethod)=t
    %------------------------------------
end
