function T = f_3_tprod(A,B,C)
T = f_tprod(B,C);
T = f_tprod(A,T);
