function memo = f_trpca_tnn(obs,opts,memo)
sz = size(obs.tY);
lamS=opts.para.lambdaS;
rho = opts.para.rho;
nu = opts.para.nu;

M=obs.tY;
% shortcuts
normTruthL=norm(double(memo.truthL(:)));
normTruthS=norm(double(memo.truthS(:)));
rankTruthL=f_tubal_rank(memo.truthL);
L0normTruthS=f_L0norm(memo.truthS);

L=zeros(sz);
H=zeros(sz);
Y1=zeros(sz);
Y2=zeros(sz);
S=zeros(sz);
T=zeros(sz);
Y3=zeros(sz);


fprintf('+++++++++f_trpca_tnn+++++++\n')
sz
for iter=1:opts.MAX_ITER_OUT
    % old point
    Hold=H; Lold=L;
    Sold=S; Told=T;
   
    % ++++ Update H and T++++
    H = (2*rho*L-2*Y2-rho*S+Y3+rho*M-Y1)/(3*rho);
    T = (2*rho*S-2*Y3-rho*L+Y2+rho*M-Y1)/(3*rho);
    % ++++ Update H  and T++++
    
    % ++++ Update L,S ++++
    [L,~] = f_prox_TNN( H+Y2/rho, 1/rho);
    
    S = f_prox_l1(T+Y3/rho,lamS/rho);
    % ++++ Update L,S ++++
    
    % ++++ Print state & Check convergence ++++
    infE = 0;
    % variable convergence
    infE=max(infE, h_inf_norm(S-Sold));
    infE=max(infE,h_inf_norm(T-Told));
    infE=max(infE,h_inf_norm(H-Hold));
    infE = max(infE, h_inf_norm(L-Lold));
    % constraint convergence
    infE = max( infE, h_inf_norm(L-H) );
    infE=max(infE,h_inf_norm(T-S));
    infE=max(infE,h_inf_norm(M-H-T));
    
    
    memo.iter=iter;
    memo.rho(iter)=rho;
    memo.eps(iter)=infE;
    
    memo.rseL(iter)=h_tnorm(double( L-memo.truthL))/normTruthL;
    memo.rseS(iter)=h_tnorm(double( S-memo.truthS ))/normTruthS;
    memo.rankL(iter)=f_tubal_rank(L);
    memo.l0normS(iter)=f_L0norm(S);
    %MSE
    memo.F2errorL(iter)=power( h_tnorm(double( L-memo.truthL)), 2 );
    memo.F2errorS(iter)=power( h_tnorm(double( S-memo.truthS)), 2 );
    memo.psnr(iter)=h_Psnr(memo.truthL,L);
    
    % Print iteration state
    if opts.verbose  && mod(iter,5)==0
        fprintf(['++%d:  eps=%0.2e, rseL=%0.2e, rseS=%0.2e,'...
                '\n\t r(L)=%d, r(Ltrue)=%d, ||S||_0=%d,||Strue||_0=%d,  \n\t rho=%0.2e, psnr=%2.3f \n'], ...
            iter, memo.eps(iter),memo.rseL(iter),memo.rseS(iter),...
            memo.rankL(iter),rankTruthL, memo.l0normS(iter),L0normTruthS, memo.rho(iter),memo.psnr(iter));
    end
    
    if ( memo.eps(iter)<opts.MAX_EPS ) || ( iter==opts.MAX_ITER_OUT )
        fprintf(['++Stop%d:  eps=%0.2e, rseL=%0.2e, rseS=%0.2e,'...
                '\n\t r(L)=%d, r(Ltrue)=%d, ||S||_0=%d,||Strue||_0=%d,  \n\t rho=%0.2e, psnr=%2.3f \n'], ...
            iter, memo.eps(iter),memo.rseL(iter),memo.rseS(iter),...
            memo.rankL(iter),rankTruthL,memo.l0normS(iter),L0normTruthS,  memo.rho(iter),memo.psnr(iter));
        break;
    end
    % ++++ Print state & Check convergence ++++
    
    
    % ++++ Dual variables ++++
    Y1 = Y1 + rho*(H+T-M);
    Y2 = Y2 + rho*(H-L);
    Y3 = Y3 + rho*(T-S);
    % ++++ Dual variables ++++
    
    % rho
    rho=min(rho*nu,opts.MAX_RHO);
end
memo.Lhat = H;
memo.Shat = T;
memo.Rank=f_tubal_rank(L);
end
