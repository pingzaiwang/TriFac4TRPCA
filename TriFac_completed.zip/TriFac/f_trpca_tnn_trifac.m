function memo = f_trpca_tnn_trifac(obs,opts,memo)

lamS=opts.para.lambdaS;
rho = opts.para.rho;
nu = opts.para.nu;
r = opts.para.r;

M=obs.tY;
sz=size(M);
% shortcuts
normTruthL=norm(double(memo.truthL(:)));
normTruthS=norm(double(memo.truthS(:)));
rankTruthL=f_tubal_rank(memo.truthL);
L0normTruthS=f_L0norm(memo.truthS);

m=sz(1);
n=sz(2);
k=sz(3);

Y = M*0;
S = M*0;
% [P,C,Q]=f_tsvd(M);
% P = ifft(P,[],3);
% C = ifft(C,[],3);
% Q= ifft(Q,[],3);
% P = P(:,1:r,:);
% C = C(1:r,1:r,:);
% Q = Q(:,1:r,:);

P =zeros([m,r,k]);
Q= zeros([n r k]);
C =zeros([r r k]);
fprintf('+++++++++f_trpca_tnn_trifac+++++++\n');
sz
tic 
for iter=1:opts.MAX_ITER_OUT
    infE = 0;
    % P 
    A = f_tprod(C,tran(Q));
    B = M-S-Y/rho;
    BAt = f_tprod(B,tran(A)); 
    P = f_tQR(BAt);
    
%     dY = f_3_tprod(P,C,tran(Q))+S-M;
%     infE = max(abs(dY(:)));
    
    % Q
    Aa = f_tprod(P,C);
    BtAa = f_tprod( tran(B), Aa);
    Q = f_tQR(BtAa);
    
%     dY = f_3_tprod(P,C,tran(Q))+S-M;
%     infE = max( infE,max(abs(dY(:))));
    
    % C 
    Tmp = f_tprod(B,Q);
    Tmp = f_tprod(tran(P),Tmp);
    C = f_prox_TNN(Tmp,1/rho);
    
%     dY = f_3_tprod(P,C,tran(Q))+S-M;
%     infE = max( infE,max(abs(dY(:))));
    
    % Tmp 
    Tmp = M-f_3_tprod(P,C,tran(Q))-Y/rho;
    S = f_prox_l1(Tmp,lamS/rho);

    L = f_3_tprod(P,C,tran(Q));
    dY = L+S-M;
    infE = max( infE,max(abs(dY(:))));
    
    % Y
    Y = Y + rho*dY;
    
    memo.iter=iter;
    memo.rho(iter)=rho;
    memo.eps(iter)=infE;
    
    memo.rseL(iter)=h_tnorm(double( L-memo.truthL))/normTruthL;
    memo.rseS(iter)=h_tnorm(double( S-memo.truthS ))/normTruthS;
    memo.rankL(iter)=f_tubal_rank(L);
    memo.l0normS(iter)=f_L0norm(S);
    %MSE
    memo.F2errorL(iter)=power( h_tnorm(double( L-memo.truthL)), 2 );
    memo.F2errorS(iter)=power( h_tnorm(double( S-memo.truthS)), 2 );
    memo.psnr(iter)=h_Psnr(memo.truthL,L);
    run_time=toc;
    % Print iteration state
    if opts.verbose  && mod(iter,1)==0
        fprintf(['++%d:  eps=%0.2e, rseL=%0.2e, rseS=%0.2e,'...
                '\n\t r(L)=%d, r(Ltrue)=%d, ||S||_0=%d,||Strue||_0=%d,  \n\t rho=%0.2e, psnr=%2.3f \n'], ...
            iter, memo.eps(iter),memo.rseL(iter),memo.rseS(iter),...
            memo.rankL(iter),rankTruthL,memo.l0normS(iter),L0normTruthS,  memo.rho(iter),memo.psnr(iter));
        fprintf('Time cost %0.4fs\n',run_time);
    end
    
    if ( memo.eps(iter) <opts.MAX_EPS )||( iter==opts.MAX_ITER_OUT )
        fprintf(['++Stop%d:  eps=%0.2e, rseL=%0.2e, rseS=%0.2e,'...
                '\n\t r(L)=%d, r(Ltrue)=%d, ||S||_0=%d,||Strue||_0=%d,  \n\t rho=%0.2e, psnr=%2.3f \n'], ...
            iter, memo.eps(iter),memo.rseL(iter),memo.rseS(iter),...
            memo.rankL(iter),rankTruthL,memo.l0normS(iter),L0normTruthS,  memo.rho(iter),memo.psnr(iter));
        fprintf('Time cost %0.4fs\n',run_time);
        break;
    end
    % ++++ Print state & Check convergence ++++
    
    % rho
    rho=min(rho*nu,opts.MAX_RHO);
end
memo.Lhat = L;
memo.Shat = S;
memo.Rank=f_tubal_rank(L);
end
